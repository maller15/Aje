/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AjedrezPGN;

/**
 *
 * @author Apa
 */
public class Tablero {
    private Pieza[][] tablero = new Pieza[8][8];

    public Tablero() {
        inicializarTablero();
    }

    public void inicializarTablero() {
        // Coloca las piezas en sus posiciones iniciales
        tablero[1][0] = new Peon("blanco", new Posicion(1, 0));
        // Continúa inicializando las demás piezas...
    }

    public Pieza obtenerPieza(int fila, int columna) {
        return tablero[fila][columna];
    }

    public void moverPieza(Posicion desde, Posicion hasta) {
        Pieza pieza = tablero[desde.fila][desde.columna];
        tablero[hasta.fila][hasta.columna] = pieza;
        tablero[desde.fila][desde.columna] = null;
        pieza.posicion = hasta;
    }
}

