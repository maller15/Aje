/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AjedrezPGN;

/**
 *
 * @author Apa
 */
import java.io.*;
import java.util.*;

public class PGNReader {
    public List<String> leerMovimientos(String archivoPGN) {
        List<String> movimientos = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(archivoPGN))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (!linea.startsWith("[")) {  // Ignorar metadatos
                    String[] movs = linea.split("\\s+"); // Separar movimientos
                    Collections.addAll(movimientos, movs);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return movimientos;
    }
}


