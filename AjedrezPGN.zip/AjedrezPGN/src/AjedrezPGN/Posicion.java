/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AjedrezPGN;

/**
 *
 * @author Apa
 */
public class Posicion {
    public int fila;
    public int columna;

    public Posicion(int fila, int columna) {
        this.fila = fila;
        this.columna = columna;
    }
}
