/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AjedrezPGN;

/**
 *
 * @author Apa
 */
import java.util.List;

public class JuegoDeAjedrez {
    private List<String> movimientos;
    private int indiceMovimientoActual;
    private Tablero tablero;

    public JuegoDeAjedrez(String archivoPGN) {
        PGNReader lector = new PGNReader();
        movimientos = lector.leerMovimientos(archivoPGN);
        tablero = new Tablero();
        indiceMovimientoActual = 0;
    }

    public void avanzarMovimiento() {
        if (indiceMovimientoActual < movimientos.size()) {
            String movimiento = movimientos.get(indiceMovimientoActual);
            // Implementa la lógica para aplicar el movimiento en el tablero
            indiceMovimientoActual++;
        }
    }

    public void retrocederMovimiento() {
        if (indiceMovimientoActual > 0) {
            indiceMovimientoActual--;
            // Implementa la lógica para deshacer el movimiento en el tablero
        }
    }

    public Tablero getTablero() {
        return tablero;
    }
}

