/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AjedrezPGN;

/**
 *
 * @author Apa
 */
public class Peon extends Pieza {
    public Peon(String color, Posicion posicion) {
        super(color, posicion);
    }

    @Override
    public boolean esMovimientoValido(Posicion nuevaPosicion) {
        // Implementa la lógica para validar el movimiento del peón
        return true; // Simplificado
    }
}

