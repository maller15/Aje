/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AjedrezPGN;

/**
 *
 * @author Apa
 */
public abstract class Pieza {
    protected String color;
    protected Posicion posicion;

    public Pieza(String color, Posicion posicion) {
        this.color = color;
        this.posicion = posicion;
    }

    public abstract boolean esMovimientoValido(Posicion nuevaPosicion);
}
