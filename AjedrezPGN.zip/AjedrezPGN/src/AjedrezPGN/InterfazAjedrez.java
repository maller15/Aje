/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AjedrezPGN;

/**
 *
 * @author Apa
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InterfazAjedrez extends JFrame {
    private JuegoDeAjedrez juego;
    private JPanel tableroPanel;

    public InterfazAjedrez(String archivoPGN) {
        juego = new JuegoDeAjedrez(archivoPGN);
        setTitle("Visor de Partida de Ajedrez");
        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        inicializarInterfaz();
    }

    private void inicializarInterfaz() {
        tableroPanel = new JPanel(new GridLayout(8, 8));
        actualizarTablero();

        JButton botonAvanzar = new JButton("Avanzar");
        botonAvanzar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                juego.avanzarMovimiento();
                actualizarTablero();
            }
        });

        JButton botonRetroceder = new JButton("Retroceder");
        botonRetroceder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                juego.retrocederMovimiento();
                actualizarTablero();
            }
        });

        JPanel panelControles = new JPanel();
        panelControles.add(botonAvanzar);
        panelControles.add(botonRetroceder);

        add(tableroPanel, BorderLayout.CENTER);
        add(panelControles, BorderLayout.SOUTH);
    }

    private void actualizarTablero() {
        tableroPanel.removeAll();
        Tablero tablero = juego.getTablero();

        for (int fila = 0; fila < 8; fila++) {
            for (int columna = 0; columna < 8; columna++) {
                Pieza pieza = tablero.obtenerPieza(fila, columna);
                JLabel label = new JLabel();

                if (pieza != null) {
                    label.setText(pieza.getClass().getSimpleName().substring(0, 1));
                    label.setForeground(pieza.color.equals("blanco") ? Color.WHITE : Color.ORANGE);
                }

                label.setOpaque(true);
                label.setBackground((fila + columna) % 2 == 0 ? Color.LIGHT_GRAY : Color.DARK_GRAY);
                label.setHorizontalAlignment(SwingConstants.CENTER);
                tableroPanel.add(label);
            }
        }

        tableroPanel.revalidate();
        tableroPanel.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            InterfazAjedrez ventana = new InterfazAjedrez("Anand.pgn");
            ventana.setVisible(true);
        });
    }
}


